操作区位于:xml_output

参考: https://blog.csdn.net/cronousgt/article/details/64137277

1.首先我们需要有一份定义你的xml文件结构的xsd文件，这里我有一份叫 GXZ.xsd 文件，这是一份描述数据库库表信息的文件，

文件描述什么的不重要，重要的是他就是你需要操作的xml文件的结构定义xsd文件，我们假设需要我们验证格式的xml文件就是 GXZ.xml文件

2.第二步我们需要生成以tableInfo.xsd文件为模版的之后可操纵tableInfo.xml文件的jar文件（当然这里不一定只是操作GXZ.xml文件，只
要是符合tableInfo.xsd文件格式的都行，名字叫abc.xml也是可以的）

		xml_output下的jar文件夹用于存放生成的对应xml的jar

		创建 GXZ.xsdconfig文件, 内容如下:
		<xb:config xmlns:xb="http://xml.apache.org/xmlbeans/2004/02/xbean/config">
			<xb:namespace>
				<xb:package>metadataCheck.controllers</xb:package>
			</xb:namespace>
		</xb:config>

		准备工作已经做好，现在我们来生成所需的操作xml的jar 在命令行输入如下命令：
		scomp -out C:\src\jar\GXZ-xmlbeans.jar  C:\src\GXZ.xsd  -compiler "C:\Program Files\Java\jdk1.8.0_20\bin\javac"  c:\src\GXZ.xsdconfig
		               所需生成jar名字              xsd文件路径                JDK环境变量	               自己创建的xsdconfig文件路径
					   
					   
3、然后就可以使用生成的jar对xml进行验证了



如果出现异常：Xmlbeans java.io.IOException: CreateProcess error=2, ????????? 

那么有可能你的java路径包含了空格，对于cmd中不识别空格的时候，可以将含有空格的路径用双引号